import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.Node;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventReader;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class Middleware {
	public Middleware()
	{
		
	}
	
	
	
	public void merge2() throws SAXException, IOException, ParserConfigurationException, TransformerException {
		File dir = new File("/eecs/home/naomi52/eclipse-workspace/Middleware/Mm");
        File[] rootFiles = dir.listFiles();
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
        DocumentBuilder db = dbf.newDocumentBuilder();
        Document doc = null;
        String myname = ""; 
        PurchCons myFinal = PurchCons.getInstance();
        myFinal.empty();
       
        
        for(int i=0; i< rootFiles.length; i++) {
        	doc = db.parse(rootFiles[i].getAbsolutePath());
        	//System.out.println(rootFiles[i].getAbsolutePath());
        	
        	//Makes a list of all items in the current P/O
        	NodeList myItems = doc.getElementsByTagName("item"); 
        	
        	//Iterating through each item
        	for( int k = 0; k< myItems.getLength(); k++)
        	{
        		//Iterating through the childnodes of each item
        		for(int j = 0; j< myItems.item(k).getChildNodes().getLength(); j++ )
        		{
        			//the current item num
        			String item = myItems.item(k).getAttributes().getNamedItem("number").getTextContent();
        			//if the map has the curr item
        			if(myFinal.containsItem(item))
        				{
        				//if the curr child node has the name "name"
        					if(myItems.item(k).getChildNodes().item(j).getNodeName().equals("name"))
        					{
        						myname = myname + myItems.item(k).getChildNodes().item(j).getTextContent();
        						//System.out.println(myname);
        					}
        					//if the curr child node has the name "quantity"
        					if(myItems.item(k).getChildNodes().item(j).getNodeName().equals("quantity"))
            				{
        						//System.out.println(myname);
        						//System.out.println(item);
            					//System.out.println("In map " + myItems.item(k).getChildNodes().item(j).getTextContent());
            					//this adds the curr quantity to the total quant in the map 
            					myFinal.addQuantity(item, myname, Integer.parseInt(myItems.item(k).getChildNodes().item(j).getTextContent()));
            					myname = new String("");
            				}
            				
        				}
        			else 
        			{
        				if(myItems.item(k).getChildNodes().item(j).getNodeName().equals("name"))
    					{
    						myname = new String(myItems.item(k).getChildNodes().item(j).getTextContent());
    					}
        				//If this is the first time it is seeing this item.
        				
        				if(myItems.item(k).getChildNodes().item(j).getNodeName().equals("quantity"))
        				{
        					//System.out.println(item);
        					//System.out.println("outside map " + myItems.item(k).getChildNodes().item(j).getTextContent());
        					//Add the curr item num and its quan to the map
        					myFinal.additemNumber(item, myname, Integer.parseInt(myItems.item(k).getChildNodes().item(j).getTextContent()));
        					myname = new String("");
        					
        				}
        			}
                }
        		
        		
        		
        	}		
        
        	
        }
                System.out.println(myFinal.toString());
        
  
	}


	public void cleanDirectory()
	{
		File dir = new File("/eecs/home/naomi52/eclipse-workspace/Middleware/Mm");
        File[] rootFiles = dir.listFiles();
        
        for(int i=0; i< rootFiles.length; i++) //move consolidated P/O files to Done directory
        {
        	//rootFiles[i].renameTo(new File("/eecs/home/naomi52/eclipse-workspace/Middleware/Done" + rootFiles[i].getName()));
        	
        }
        for(int i=0; i< rootFiles.length; i++) //delete consolidated P/O files
        {
        	//rootFiles[i].delete();
        	
        }
        
	}
	

}
